package com.example.tabbar_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
