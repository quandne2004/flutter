import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Example with TabBar & Scaffold',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const TabBarExample(),
    );
  }
}

class TabBarExample extends StatefulWidget {
  const TabBarExample({super.key});

  @override
  _TabBarExampleState createState() => _TabBarExampleState();
}

class _TabBarExampleState extends State<TabBarExample> {
  int _selectedIndex = 0;

  final List<Widget> _tabs = [
    const CarTab(),
    const TransitTab(),
    const BikeTab(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,  // Số tab
      child: Scaffold(
        appBar: AppBar(
          title: const Text('TabBar Example with BottomNavigation'),
          bottom: const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.directions_car), text: 'Car'),
              Tab(icon: Icon(Icons.directions_transit), text: 'Transit'),
              Tab(icon: Icon(Icons.directions_bike), text: 'Bike'),
            ],
          ),
        ),
        body: TabBarView(
          children: _tabs,
        ),
        bottomNavigationBar: BottomNavigationBar(
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.business),
              label: 'Business',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.school),
              label: 'School',
            ),
          ],
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            showDialog(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  title: const Text('Floating Action Button'),
                  content: const Text('You clicked the Floating Action Button!'),
                  actions: [
                    TextButton(
                      child: const Text('OK'),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                );
              },
            );
          },
          child: const Icon(Icons.add),
        ),
      ),
    );
  }
}

class CarTab extends StatefulWidget {
  const CarTab({super.key});

  @override
  _CarTabState createState() => _CarTabState();
}

class _CarTabState extends State<CarTab> {
  DateTime? _selectedDate;

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
      _showSuccessDialog(context);
    }
  }

  void _showSuccessDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Success'),
          content: const Text('Date has been successfully set!'),
          actions: [
            TextButton(
              child: const Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _showDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Dialog Title'),
          content: const Text('This is a simple dialog.'),
          actions: [
            TextButton(
              child: const Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        ListTile(
          leading: const Icon(Icons.directions_car),
          title: const Text('Car 1'),
          subtitle: const Text('Description of Car 1'),
          trailing: IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: () => _selectDate(context),
          ),
        ),
        ListTile(
          leading: const Icon(Icons.directions_car),
          title: const Text('Car 2'),
          subtitle: const Text('Description of Car 2'),
          trailing: IconButton(
            icon: const Icon(Icons.info),
            onPressed: () => _showDialog(context),
          ),
        ),
        ListTile(
          leading: const Icon(Icons.directions_car),
          title: const Text('Car 3'),
          subtitle: Text(
              'Selected date: ${_selectedDate != null ? _selectedDate.toString().split(' ')[0] : 'None'}'),
          trailing: IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: () => _selectDate(context),
          ),
        ),
      ],
    );
  }
}

class TransitTab extends StatelessWidget {
  const TransitTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        ListTile(
          leading: Icon(Icons.directions_transit),
          title: Text('Transit 1'),
          subtitle: Text('Description of Transit 1'),
        ),
        ListTile(
          leading: Icon(Icons.directions_transit),
          title: Text('Transit 2'),
          subtitle: Text('Description of Transit 2'),
        ),
        ListTile(
          leading: Icon(Icons.directions_transit),
          title: Text('Transit 3'),
          subtitle: Text('Description of Transit 3'),
        ),
      ],
    );
  }
}

class BikeTab extends StatelessWidget {
  const BikeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        ListTile(
          leading: Icon(Icons.directions_bike),
          title: Text('Bike 1'),
          subtitle: Text('Description of Bike 1'),
        ),
        ListTile(
          leading: Icon(Icons.directions_bike),
          title: Text('Bike 2'),
          subtitle: Text('Description of Bike 2'),
        ),
        ListTile(
          leading: Icon(Icons.directions_bike),
          title: Text('Bike 3'),
          subtitle: Text('Description of Bike 3'),
        ),
      ],
    );
  }
}
