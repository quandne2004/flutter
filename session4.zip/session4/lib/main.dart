import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Widgets Example',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const WidgetsExample(),
    );
  }
}

class WidgetsExample extends StatelessWidget {
  const WidgetsExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Widgets Example'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const TextWidgetExample(),
            const SizedBox(height: 20),
            const ImageWidgetExample(),
            const SizedBox(height: 20),
            const IconWidgetExample(),
            const SizedBox(height: 20),
            const FormWidgetExample(),
          ],
        ),
      ),
    );
  }
}

class TextWidgetExample extends StatelessWidget {
  const TextWidgetExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Text Widget Example',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.blueAccent,
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          'Flutter provides a wide range of styles for the Text widget such as bold, italic, and colored text. You can also adjust line spacing, text alignment, and more.',
          style: TextStyle(fontSize: 16, color: Colors.black87),
        ),
      ],
    );
  }
}

class ImageWidgetExample extends StatelessWidget {
  const ImageWidgetExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Image Widget Example',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.blueAccent,
          ),
        ),
        const SizedBox(height: 10),
        Container(
          width: 150, // Chiều rộng của hình vuông
          height: 150, // Chiều cao của hình vuông
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0), // Optional: for rounded corners
            image: DecorationImage(
              image: AssetImage('assets/images/pic0.jpg'), // Đường dẫn đến hình ảnh trong assets
              fit: BoxFit.cover,
            ),
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          'Images can be loaded from assets or network. Adjust image size and fit using properties like width, height, and fit.',
          style: TextStyle(fontSize: 16, color: Colors.black87),
        ),
      ],
    );
  }
}

class IconWidgetExample extends StatelessWidget {
  const IconWidgetExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Icon Widget Example',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.blueAccent,
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: const [
            Icon(
              Icons.favorite,
              color: Colors.red,
              size: 50,
            ),
            SizedBox(width: 20),
            Icon(
              Icons.star,
              color: Colors.yellow,
              size: 50,
            ),
            SizedBox(width: 20),
            Icon(
              Icons.thumb_up,
              color: Colors.blue,
              size: 50,
            ),
          ],
        ),
        const SizedBox(height: 10),
        const Text(
          'Icons can be used to represent different actions or states. Customize their size, color, and arrangement.',
          style: TextStyle(fontSize: 16, color: Colors.black87),
        ),
      ],
    );
  }
}

class FormWidgetExample extends StatefulWidget {
  const FormWidgetExample({super.key});

  @override
  _FormWidgetExampleState createState() => _FormWidgetExampleState();
}

class _FormWidgetExampleState extends State<FormWidgetExample> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Hello, ${_nameController.text}!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Form Widget Example',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.blueAccent,
            ),
          ),
          const SizedBox(height: 10),
          TextFormField(
            controller: _nameController,
            decoration: const InputDecoration(
              labelText: 'Enter your name',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.person),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter your name';
              }
              return null;
            },
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: _submitForm,
            child: const Text('Submit'),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all(Colors.blue), // Background color
              foregroundColor: MaterialStateProperty.all(Colors.white), // Text color
              padding: MaterialStateProperty.all(const EdgeInsets.symmetric(vertical: 15.0, horizontal: 20.0)),
              textStyle: MaterialStateProperty.all(const TextStyle(fontSize: 18)),
            ),
          ),
        ],
      ),
    );
  }
}
